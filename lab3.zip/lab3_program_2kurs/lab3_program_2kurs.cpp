﻿#include <typeinfo>
#include <fstream>
#include "figure.h"
#include "Ring.h"
#include "Triangle.h"
#include "Star.h"
#include "Rect.h"
#include "aggregate.h"
#include "..\\glut.h"


using namespace std;

void keyboard(int key, int x, int y)
{
    int c1, c2, c3;
    c1 = Figure::c1;//сохраняем текущий цвет рисования 
    c2 = Figure::c2;
    c3 = Figure::c3;

        switch (key)
        {

        case GLUT_KEY_F3://для переключения между фигурами 
            if (Figure::i < Figure::count)//последовательное перемещение между фигурами, начиная с последней созданной
                Figure::i++;
            else Figure::i = 0;
            
            //выделение//
            Figure::col1 = 0;
            Figure::col2 = 1;
            Figure::col3 = 1;//цвет выделения активной фигуры - голубой
           
            Figure::p[Figure::i]->square();//перерисовка выделения
            
            Figure::col1 = 1;
            Figure::col2 = 1;
            Figure::col3 = 1;//изменение цвета выделения активной фигуры на белый

            for (int i = 0; i < Figure::count+1; i++)//перерисовка выделения
            {
                if (i != Figure::i)//если фигура не активная, нарисовать ее контур белым 
                {
                    Figure::p[i]->square();
                }
            }

            break;

        case GLUT_KEY_F4://добавить в агрегат 
            if (Figure::aggregate != 0)//если нажата кнопка создать агрегат 
            {
                Figure::p[Figure::aggregate]->add(Figure::p[Figure::i]);

                Figure::p[Figure::aggregate]->display(true);

            }
            break;


        case GLUT_KEY_INSERT://остановить создание агрегата 
            if (Figure::aggregate != 0)//если нажата кнопка создать агрегат 
            {
                Figure::aggregate = 0;

            }
            break;


        case GLUT_KEY_UP:
            if (Figure::aggregate == 0)
            {
                if (typeid(*(Figure::p[Figure::i])) != typeid(Star) && typeid(*(Figure::p[Figure::i])) != typeid(Aggregate))
                {
                    if (Figure::p[Figure::i]->gety() > 16)//фигура не может выходить за границу окна
                    {
                        if (Figure::flag == true)//если выбран пункт меню движение
                        {
                            Figure::crossing = false;
                            for (int i = 0; i < Figure::count + 1; i++)
                            {
                                if (typeid(*(Figure::p[i])) != typeid(Aggregate))
                                {
                                    if (Figure::p[Figure::i]->getcrossy1() == Figure::p[i]->getcrossy2() &&
                                        Figure::p[Figure::i]->getcrossx1() >= Figure::p[i]->getcrossx1() &&
                                        Figure::p[Figure::i]->getcrossx1() <= Figure::p[i]->getcrossx2() ||
                                        Figure::p[Figure::i]->getcrossy1() == Figure::p[i]->getcrossy2() &&
                                        Figure::p[Figure::i]->getcrossx2() >= Figure::p[i]->getcrossx1() &&
                                        Figure::p[Figure::i]->getcrossx2() <= Figure::p[i]->getcrossx2())
                                    {
                                        Figure::crossing = true;

                                    }
                                }

                                if (typeid(*(Figure::p[i])) == typeid(Aggregate))
                                {
                                    for (int j = 0; j < Figure::p[i]->getn() + 1; j++)
                                    {
                                        if (Figure::p[Figure::i]->getcrossy1() == Figure::p[i]->getcrossy2(j) &&
                                            Figure::p[Figure::i]->getcrossx1() >= Figure::p[i]->getcrossx1(j) &&
                                            Figure::p[Figure::i]->getcrossx1() <= Figure::p[i]->getcrossx2(j) ||
                                            Figure::p[Figure::i]->getcrossy1() == Figure::p[i]->getcrossy2(j) &&
                                            Figure::p[Figure::i]->getcrossx2() >= Figure::p[i]->getcrossx1(j) &&
                                            Figure::p[Figure::i]->getcrossx2() <= Figure::p[i]->getcrossx2(j))
                                        {
                                            Figure::crossing = true;
                                        }
                                    }
                                }
                            }
                            if (Figure::crossing == false)//если нет столкновения, осуществить движение
                            {
                                Figure::p[Figure::i]->sety(-1);
                                if (Figure::StartRec == true)//если включена запись траектории
                                {
                                    Figure::y_[Figure::indexY] = -1;
                                    Figure::indexY++;
                                    Figure::orderXY[Figure::indexOrderXY] = 0;
                                    Figure::indexOrderXY++;
                                }
                            }
                        }
                    }
                }

                else if (typeid(*(Figure::p[Figure::i])) == typeid(Aggregate))
                {
                    if (Figure::flag == true)//если выбран пункт меню движение
                    {
                        if (Figure::p[Figure::i]->stopUP() == 0)
                        {
                            Figure::p[Figure::i]->sety(-1);
                        }

                        if (Figure::StartRec == true)//если включена запись траектории
                        {
                            Figure::y_[Figure::indexY] = -1;
                            Figure::indexY++;
                            Figure::orderXY[Figure::indexOrderXY] = 0;
                            Figure::indexOrderXY++;
                        }
                    }
                }

                else
                {
                    if (Figure::p[Figure::i]->gety() > 26)
                    {
                        if (Figure::flag == true)//если выбран пункт меню движение
                        {
                            Figure::crossing = false;
                            for (int i = 0; i < Figure::count + 1; i++)
                            {
                                //проверка на столкновение 
                                if (typeid(*(Figure::p[i])) != typeid(Aggregate))
                                {
                                    if (Figure::p[Figure::i]->getcrossy1() == Figure::p[i]->getcrossy2() &&
                                        Figure::p[Figure::i]->getcrossx1() >= Figure::p[i]->getcrossx1() &&
                                        Figure::p[Figure::i]->getcrossx1() <= Figure::p[i]->getcrossx2() ||
                                        Figure::p[Figure::i]->getcrossy1() == Figure::p[i]->getcrossy2() &&
                                        Figure::p[Figure::i]->getcrossx2() >= Figure::p[i]->getcrossx1() &&
                                        Figure::p[Figure::i]->getcrossx2() <= Figure::p[i]->getcrossx2())
                                    {
                                        Figure::crossing = true;

                                    }
                                }
                                if (typeid(*(Figure::p[i])) == typeid(Aggregate))
                                {
                                    for (int j = 0; j < Figure::p[i]->getn() + 1; j++)
                                    {
                                        if (Figure::p[Figure::i]->getcrossy1() == Figure::p[i]->getcrossy2(j) &&
                                            Figure::p[Figure::i]->getcrossx1() >= Figure::p[i]->getcrossx1(j) &&
                                            Figure::p[Figure::i]->getcrossx1() <= Figure::p[i]->getcrossx2(j) ||
                                            Figure::p[Figure::i]->getcrossy1() == Figure::p[i]->getcrossy2(j) &&
                                            Figure::p[Figure::i]->getcrossx2() >= Figure::p[i]->getcrossx1(j) &&
                                            Figure::p[Figure::i]->getcrossx2() <= Figure::p[i]->getcrossx2(j))
                                        {
                                            Figure::crossing = true;
                                        }
                                    }
                                }
                            }
                            if (Figure::crossing == false)//если столкновения нет, выполнить движение или запись траектории
                            {
                                Figure::p[Figure::i]->sety(-1);
                                if (Figure::StartRec == true)//если включена запись траектории
                                {
                                    Figure::y_[Figure::indexY] = -1;
                                    Figure::indexY++;
                                    Figure::orderXY[Figure::indexOrderXY] = 0;
                                    Figure::indexOrderXY++;
                                }
                            }
                        }
                    }

                }
            }
            else
            {
                Figure::p[Figure::i]->sety(-1);

            }

            break;

        case GLUT_KEY_DOWN:
            if (Figure::aggregate == 0)
            {
                if (typeid(*(Figure::p[Figure::i])) == typeid(Rect) && typeid(*(Figure::p[Figure::i])) != typeid(Aggregate) || typeid(*(Figure::p[Figure::i])) == typeid(Triangle) && typeid(*(Figure::p[Figure::i])) != typeid(Aggregate))
                {
                    if (Figure::p[Figure::i]->gety() < 170)//фигура не может выходить за границу окна
                    {
                        if (Figure::flag == true)//если выбран пункт меню движение
                        {
                            Figure::crossing = false;
                            for (int i = 0; i < Figure::count + 1; i++)
                            {
                                if (typeid(*(Figure::p[i])) != typeid(Aggregate))
                                {
                                    if (Figure::p[Figure::i]->getcrossy2() == Figure::p[i]->getcrossy1() &&
                                        Figure::p[Figure::i]->getcrossx1() >= Figure::p[i]->getcrossx1() &&
                                        Figure::p[Figure::i]->getcrossx1() <= Figure::p[i]->getcrossx2() ||
                                        Figure::p[Figure::i]->getcrossy2() == Figure::p[i]->getcrossy1() &&
                                        Figure::p[Figure::i]->getcrossx2() >= Figure::p[i]->getcrossx1() &&
                                        Figure::p[Figure::i]->getcrossx2() <= Figure::p[i]->getcrossx2())
                                    {
                                        Figure::crossing = true;


                                    }
                                }
                                if (typeid(*(Figure::p[i])) == typeid(Aggregate))
                                {
                                    for (int j = 0; j < Figure::p[i]->getn() + 1; j++)
                                    {
                                        if (Figure::p[Figure::i]->getcrossy2() == Figure::p[i]->getcrossy1(j) &&
                                            Figure::p[Figure::i]->getcrossx1() >= Figure::p[i]->getcrossx1(j) &&
                                            Figure::p[Figure::i]->getcrossx1() <= Figure::p[i]->getcrossx2(j) ||
                                            Figure::p[Figure::i]->getcrossy2() == Figure::p[i]->getcrossy1(j) &&
                                            Figure::p[Figure::i]->getcrossx2() >= Figure::p[i]->getcrossx1(j) &&
                                            Figure::p[Figure::i]->getcrossx2() <= Figure::p[i]->getcrossx2(j))
                                        {
                                            Figure::crossing = true;
                                        }
                                    }
                                }
                            }
                            if (Figure::crossing == false)
                            {

                                Figure::p[Figure::i]->sety(1);
                                if (Figure::StartRec == true)//если включена запись траектории
                                {
                                    Figure::y_[Figure::indexY] = 1;
                                    Figure::indexY++;
                                    Figure::orderXY[Figure::indexOrderXY] = 0;
                                    Figure::indexOrderXY++;
                                }
                            }

                        }
                    }
                }
                else if (typeid(*(Figure::p[Figure::i])) == typeid(Aggregate))
                {
                    if (Figure::flag == true)//если выбран пункт меню движение
                    {
                        if (Figure::p[Figure::i]->stopDOWN() == 0)
                        {
                            Figure::p[Figure::i]->sety(1);
                        }

                        if (Figure::StartRec == true)//если включена запись траектории
                        {
                            Figure::y_[Figure::indexY] = 1;
                            Figure::indexY++;
                            Figure::orderXY[Figure::indexOrderXY] = 0;
                            Figure::indexOrderXY++;
                        }
                    }


                }
                else
                {
                    if (Figure::p[Figure::i]->gety() < 180)//фигура не может выходить за границу окна
                    {
                        if (Figure::flag == true)//если выбран пункт меню движение
                        {
                            Figure::crossing = false;

                            for (int i = 0; i < Figure::count + 1; i++)
                            {
                                if (typeid(*(Figure::p[i])) != typeid(Aggregate))
                                {
                                    if (Figure::p[Figure::i]->getcrossy2() == Figure::p[i]->getcrossy1() &&
                                        Figure::p[Figure::i]->getcrossx1() >= Figure::p[i]->getcrossx1() &&
                                        Figure::p[Figure::i]->getcrossx1() <= Figure::p[i]->getcrossx2() ||
                                        Figure::p[Figure::i]->getcrossy2() == Figure::p[i]->getcrossy1() &&
                                        Figure::p[Figure::i]->getcrossx2() >= Figure::p[i]->getcrossx1() &&
                                        Figure::p[Figure::i]->getcrossx2() <= Figure::p[i]->getcrossx2())
                                    {
                                        Figure::crossing = true;

                                    }
                                }
                                if (typeid(*(Figure::p[i])) == typeid(Aggregate))
                                {
                                    for (int j = 0; j < Figure::p[i]->getn() + 1; j++)
                                    {
                                        if (Figure::p[Figure::i]->getcrossy2() == Figure::p[i]->getcrossy1(j) &&
                                            Figure::p[Figure::i]->getcrossx1() >= Figure::p[i]->getcrossx1(j) &&
                                            Figure::p[Figure::i]->getcrossx1() <= Figure::p[i]->getcrossx2(j) ||
                                            Figure::p[Figure::i]->getcrossy2() == Figure::p[i]->getcrossy1(j) &&
                                            Figure::p[Figure::i]->getcrossx2() >= Figure::p[i]->getcrossx1(j) &&
                                            Figure::p[Figure::i]->getcrossx2() <= Figure::p[i]->getcrossx2(j))
                                        {
                                            Figure::crossing = true;
                                        }
                                    }
                                }
                            }
                            if (Figure::crossing == false)
                            {

                                Figure::p[Figure::i]->sety(1);
                                if (Figure::StartRec == true)//если включена запись траектории
                                {
                                    Figure::y_[Figure::indexY] = 1;
                                    Figure::indexY++;
                                    Figure::orderXY[Figure::indexOrderXY] = 0;
                                    Figure::indexOrderXY++;
                                }
                            }
                        }
                    }
                }
            }
            else
            {
                Figure::p[Figure::i]->sety(1);

            }

                break;

        case GLUT_KEY_LEFT:
            if (Figure::aggregate == 0)
            {
                if (typeid(*(Figure::p[Figure::i])) != typeid(Rect) && typeid(*(Figure::p[Figure::i])) != typeid(Aggregate))
                {
                    if (Figure::p[Figure::i]->getx() > 20)//фигура не может выходить за границу окна
                    {
                        if (Figure::flag == true)//если выбран пункт меню движение
                        {
                            Figure::crossing = false;

                            for (int i = 0; i < Figure::count + 1; i++)
                            {
                                if (typeid(*(Figure::p[i])) != typeid(Aggregate))
                                {
                                    if (Figure::p[Figure::i]->getcrossx1() == Figure::p[i]->getcrossx2() &&
                                        Figure::p[Figure::i]->getcrossy1() >= Figure::p[i]->getcrossy1() &&
                                        Figure::p[Figure::i]->getcrossy1() <= Figure::p[i]->getcrossy2() ||
                                        Figure::p[Figure::i]->getcrossx1() == Figure::p[i]->getcrossx2() &&
                                        Figure::p[Figure::i]->getcrossy2() >= Figure::p[i]->getcrossy1() &&
                                        Figure::p[Figure::i]->getcrossy2() <= Figure::p[i]->getcrossy2())
                                    {
                                        Figure::crossing = true;

                                    }
                                }
                                if (typeid(*(Figure::p[i])) == typeid(Aggregate))
                                {
                                    for (int j = 0; j < Figure::p[i]->getn() + 1; j++)
                                    {
                                        if (Figure::p[Figure::i]->getcrossx1() == Figure::p[i]->getcrossx2(j) &&
                                            Figure::p[Figure::i]->getcrossy1() >= Figure::p[i]->getcrossy1(j) &&
                                            Figure::p[Figure::i]->getcrossy1() <= Figure::p[i]->getcrossy2(j) ||
                                            Figure::p[Figure::i]->getcrossx1() == Figure::p[i]->getcrossx2(j) &&
                                            Figure::p[Figure::i]->getcrossy2() >= Figure::p[i]->getcrossy1(j) &&
                                            Figure::p[Figure::i]->getcrossy2() <= Figure::p[i]->getcrossy2(j))
                                        {
                                            Figure::crossing = true;
                                        }
                                    }
                                }
                            }
                            if (Figure::crossing == false)
                            {
                                Figure::p[Figure::i]->setx(-1);
                                if (Figure::StartRec == true)//если включена запись траектории
                                {
                                    Figure::x_[Figure::indexX] = -1;
                                    Figure::indexX++;
                                    Figure::orderXY[Figure::indexOrderXY] = 1;
                                    Figure::indexOrderXY++;

                                }
                            }
                        }
                    }
                }
            else if (typeid(*(Figure::p[Figure::i])) == typeid(Aggregate))
            {
                if (Figure::flag == true)//если выбран пункт меню движение
                {
                    if (Figure::p[Figure::i]->stopLEFT() == 0)
                    {
                        Figure::p[Figure::i]->setx(-1);
                    }

                    if (Figure::StartRec == true)//если включена запись траектории
                    {
                        Figure::x_[Figure::indexX] = -1;
                        Figure::indexX++;
                        Figure::orderXY[Figure::indexOrderXY] = 1;
                        Figure::indexOrderXY++;

                    }
                }
            }
            else
            {
                if (Figure::p[Figure::i]->getx() > 10)//фигура не может выходить за границу окна
                {
                    if (Figure::flag == true)//если выбран пункт меню движение
                    {
                        Figure::crossing = false;

                        for (int i = 0; i < Figure::count + 1; i++)
                        {
                            if (typeid(*(Figure::p[i])) != typeid(Aggregate))
                            {
                                if (Figure::p[Figure::i]->getcrossx1() == Figure::p[i]->getcrossx2() &&
                                    Figure::p[Figure::i]->getcrossy1() >= Figure::p[i]->getcrossy1() &&
                                    Figure::p[Figure::i]->getcrossy1() <= Figure::p[i]->getcrossy2() ||
                                    Figure::p[Figure::i]->getcrossx1() == Figure::p[i]->getcrossx2() &&
                                    Figure::p[Figure::i]->getcrossy2() >= Figure::p[i]->getcrossy1() &&
                                    Figure::p[Figure::i]->getcrossy2() <= Figure::p[i]->getcrossy2())
                                {
                                    Figure::crossing = true;

                                }
                            }
                            if (typeid(*(Figure::p[i])) == typeid(Aggregate))
                            {
                                for (int j = 0; j < Figure::p[i]->getn() + 1; j++)
                                {
                                    if (Figure::p[Figure::i]->getcrossx1() == Figure::p[i]->getcrossx2(j) &&
                                        Figure::p[Figure::i]->getcrossy1() >= Figure::p[i]->getcrossy1(j) &&
                                        Figure::p[Figure::i]->getcrossy1() <= Figure::p[i]->getcrossy2(j) ||
                                        Figure::p[Figure::i]->getcrossx1() == Figure::p[i]->getcrossx2(j) &&
                                        Figure::p[Figure::i]->getcrossy2() >= Figure::p[i]->getcrossy1(j) &&
                                        Figure::p[Figure::i]->getcrossy2() <= Figure::p[i]->getcrossy2(j))
                                    {
                                        Figure::crossing = true;
                                    }
                                }
                            }
                        }
                        if (Figure::crossing == false)
                        {
                            Figure::p[Figure::i]->setx(-1);
                            if (Figure::StartRec == true)//если включена запись траектории
                            {
                                Figure::x_[Figure::indexX] = -1;
                                Figure::indexX++;
                                Figure::orderXY[Figure::indexOrderXY] = 1;
                                Figure::indexOrderXY++;

                            }
                        }
                    }
                }
            }
        }
        else
        {
           Figure::p[Figure::i]->setx(-1);
        }

            
            break;
        case GLUT_KEY_RIGHT:
            if (Figure::aggregate == 0)
            {
                if (typeid(*(Figure::p[Figure::i])) != typeid(Star) && typeid(*(Figure::p[Figure::i])) != typeid(Aggregate))
                {
                    if (Figure::p[Figure::i]->getx() < 180)//фигура не может выходить за границу окна
                    {
                        if (Figure::flag == true)//если выбран пункт меню движение
                        {
                            Figure::crossing = false;

                            for (int i = 0; i < Figure::count + 1; i++)
                            {
                                if (typeid(*(Figure::p[i])) != typeid(Aggregate))
                                {
                                    if (Figure::p[Figure::i]->getcrossx2() == Figure::p[i]->getcrossx1() &&
                                        Figure::p[Figure::i]->getcrossy1() >= Figure::p[i]->getcrossy1() &&
                                        Figure::p[Figure::i]->getcrossy1() <= Figure::p[i]->getcrossy2() ||
                                        Figure::p[Figure::i]->getcrossx2() == Figure::p[i]->getcrossx1() &&
                                        Figure::p[Figure::i]->getcrossy2() >= Figure::p[i]->getcrossy1() &&
                                        Figure::p[Figure::i]->getcrossy2() <= Figure::p[i]->getcrossy2())
                                    {
                                        Figure::crossing = true;

                                    }
                                }
                                if (typeid(*(Figure::p[i])) == typeid(Aggregate))
                                {
                                    for (int j = 0; j < Figure::p[i]->getn() + 1; j++)
                                    {
                                        if (Figure::p[Figure::i]->getcrossx2() == Figure::p[i]->getcrossx1(j) &&
                                            Figure::p[Figure::i]->getcrossy1() >= Figure::p[i]->getcrossy1(j) &&
                                            Figure::p[Figure::i]->getcrossy1() <= Figure::p[i]->getcrossy2(j) ||
                                            Figure::p[Figure::i]->getcrossx2() == Figure::p[i]->getcrossx1(j) &&
                                            Figure::p[Figure::i]->getcrossy2() >= Figure::p[i]->getcrossy1(j) &&
                                            Figure::p[Figure::i]->getcrossy2() <= Figure::p[i]->getcrossy2(j))
                                        {
                                            Figure::crossing = true;
                                        }
                                    }
                                }
                            }
                            if (Figure::crossing == false)
                            {
                                Figure::p[Figure::i]->setx(1);
                                if (Figure::StartRec == true)//если включена запись траектории
                                {
                                    Figure::x_[Figure::indexX] = 1;
                                    Figure::indexX++;
                                    Figure::orderXY[Figure::indexOrderXY] = 1;
                                    Figure::indexOrderXY++;

                                }
                            }
                        }
                    }
                }
                else if (typeid(*(Figure::p[Figure::i])) == typeid(Aggregate))
                {
                    if (Figure::flag == true)//если выбран пункт меню движение
                    {
                        if (Figure::p[Figure::i]->stopRIGHT() == 0)
                        {
                            Figure::p[Figure::i]->setx(1);
                        }

                        if (Figure::StartRec == true)//если включена запись траектории
                        {
                            Figure::x_[Figure::indexX] = 1;
                            Figure::indexX++;
                            Figure::orderXY[Figure::indexOrderXY] = 1;
                            Figure::indexOrderXY++;

                        }
                    }

                }

                else
                {
                    if (Figure::p[Figure::i]->getx() < 190)//фигура не может выходить за границу окна
                    {
                        if (Figure::flag == true)//если выбран пункт меню движение
                        {
                            Figure::crossing = false;

                            for (int i = 0; i < Figure::count + 1; i++)
                            {
                                if (typeid(*(Figure::p[i])) != typeid(Aggregate))
                                {
                                    if (Figure::p[Figure::i]->getcrossx2() == Figure::p[i]->getcrossx1() &&
                                        Figure::p[Figure::i]->getcrossy1() >= Figure::p[i]->getcrossy1() &&
                                        Figure::p[Figure::i]->getcrossy1() <= Figure::p[i]->getcrossy2() ||
                                        Figure::p[Figure::i]->getcrossx2() == Figure::p[i]->getcrossx1() &&
                                        Figure::p[Figure::i]->getcrossy2() >= Figure::p[i]->getcrossy1() &&
                                        Figure::p[Figure::i]->getcrossy2() <= Figure::p[i]->getcrossy2())
                                    {
                                        Figure::crossing = true;

                                    }
                                }
                                if (typeid(*(Figure::p[i])) == typeid(Aggregate))
                                {
                                    for (int j = 0; j < Figure::p[i]->getn() + 1; j++)
                                    {
                                        if (Figure::p[Figure::i]->getcrossx2() == Figure::p[i]->getcrossx1(j) &&
                                            Figure::p[Figure::i]->getcrossy1() >= Figure::p[i]->getcrossy1(j) &&
                                            Figure::p[Figure::i]->getcrossy1() <= Figure::p[i]->getcrossy2(j) ||
                                            Figure::p[Figure::i]->getcrossx2() == Figure::p[i]->getcrossx1(j) &&
                                            Figure::p[Figure::i]->getcrossy2() >= Figure::p[i]->getcrossy1(j) &&
                                            Figure::p[Figure::i]->getcrossy2() <= Figure::p[i]->getcrossy2(j))
                                        {
                                            Figure::crossing = true;
                                        }
                                    }
                                }
                            }
                            if (Figure::crossing == false)
                            {
                                Figure::p[Figure::i]->setx(1);
                                if (Figure::StartRec == true)//если включена запись траектории
                                {
                                    Figure::x_[Figure::indexX] = 1;
                                    Figure::indexX++;
                                    Figure::orderXY[Figure::indexOrderXY] = 1;
                                    Figure::indexOrderXY++;

                                }
                            }
                        }
                    }

                }
            }
            else
            {
                Figure::p[Figure::i]->setx(1);
            }
            break;

        }

        if (Figure::p[Figure::i]->getwhite() == 0)
        {
            Figure::c1 = Figure::p[Figure::i]->getc1();
            Figure::c2 = Figure::p[Figure::i]->getc2();
            Figure::c3 = Figure::p[Figure::i]->getc3();
            Figure::col1 = 0;
            Figure::col2 = 1;
            Figure::col3 = 1;
            Figure::p[Figure::i]->square();
            
        }

        else
        {
            Figure::c1 = 1;
            Figure::c2 = 1;
            Figure::c3 = 1;
           
            Figure::col1 = 1;
            Figure::col2 = 1;
            Figure::col3 = 1;

            Figure::p[Figure::i]->square();
        }

        Figure::p[Figure::i]->display(true);

    if (Figure::count > -1)//перерисовать все фигуры, что были созданны
    {
        for (int i = 0; i < Figure::count + 1; i++)
        {
            if (i != Figure::i)
            {
                if (Figure::p[i]->getwhite() == 0)
                {
                    Figure::c1 = Figure::p[i]->getc1();
                    Figure::c2 = Figure::p[i]->getc2();
                    Figure::c3 = Figure::p[i]->getc3();
                   
                    Figure::col1 = 1;
                    Figure::col2 = 1;
                    Figure::col3 = 1;
                    Figure::p[i]->square();
                    
                }

                else
                {
                    Figure::c1 = 1;
                    Figure::c2 = 1;
                    Figure::c3 = 1;
                    
                    Figure::col1 = 1;
                    Figure::col2 = 1;
                    Figure::col3 = 1;
                    Figure::p[i]->square();

                    

                }
                Figure::p[i]->display(true);
            }
        }
       
    }

    Figure::c1 = c1;//возвращаем текущий цвет рисования
    Figure::c2 = c2;
    Figure::c3 = c3;
   
    glutPostRedisplay();
    
}


void reshape(int w, int h)//функция изменения размера окна
{
    glutReshapeWindow(900, 700);
    glViewport(0, 0, 900, 700);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    gluOrtho2D(0, 200, 200, 0);
    glutPositionWindow(100, 100);

    glClearColor(1, 1, 1, 1);//установить белый цвет фона
    glClear(GL_COLOR_BUFFER_BIT);

    int c1, c2, c3;
    c1 = Figure::c1;//сохраняем текущий цвет рисования 
    c2 = Figure::c2;
    c3 = Figure::c3;

    if (Figure::count > -1)//перерисовать все фигуры, что были созданны
    {
        for (int i = 0; i < Figure::count + 1; i++)
        {
            if (Figure::p[i]->getwhite() == 0)
            {
                Figure::c1 = Figure::p[i]->getc1();
                Figure::c2 = Figure::p[i]->getc2();
                Figure::c3 = Figure::p[i]->getc3();
                if (i == Figure::i)
                {
                    Figure::col1 = 0;
                    Figure::col2 = 1;
                    Figure::col3 = 1;
                    Figure::p[i]->square();
                }
            }

            else
            {
                Figure::c1 = 1;
                Figure::c2 = 1;
                Figure::c3 = 1;
                if (i == Figure::i)
                {
                    Figure::col1 = 1;
                    Figure::col2 = 1;
                    Figure::col3 = 1;

                    Figure::p[i]->square();

                }
            }
            Figure::p[i]->display(true);
        }
    }

    Figure::c1 = c1;//возвращаем текущий цвет рисования
    Figure::c2 = c2;
    Figure::c3 = c3;

    glMatrixMode(GL_MODELVIEW);

    glLoadIdentity();

    glFlush();
    glutSwapBuffers();
}

enum keys4menu {Cap1, Cap2, Cap3, Cap4, Agg, Cap5, Cap6, Cap7, Cap8, Cap9, Cap10, Hide, Move, Clear, Path, PathMove, File, ReadFile} KeysMenu;



void Menu(int key)
{
    ofstream file;
    ifstream file1;

    

    int c1, c2, c3;
    c1 = Figure::c1;//сохраняем текущий цвет рисования 
    c2 = Figure::c2;
    c3 = Figure::c3;

    if (Figure::count > -1)//перерисовать все фигуры, что были созданны
    {
        for (int i = 0; i < Figure::count + 1; i++)
        {
                if (Figure::p[i]->getwhite() == 0)//если фигура не белая
                {
                    Figure::c1 = Figure::p[i]->getc1();
                    Figure::c2 = Figure::p[i]->getc2();
                    Figure::c3 = Figure::p[i]->getc3();

                    if (i == Figure::i)
                    {
                        Figure::col1 = 0;
                        Figure::col2 = 1;
                        Figure::col3 = 1;
                        Figure::p[i]->square();

                    }

                }
                else
                {
                    Figure::c1 = 1;
                    Figure::c2 = 1;
                    Figure::c3 = 1;
                    if (i == Figure::i)
                    {
                        Figure::col1 = 1;
                        Figure::col2 = 1;
                        Figure::col3 = 1;

                        Figure::p[i]->square();

                    }

                }

                Figure::p[i]->display(true);
                
        }
    }
    
    
    Figure::c1 = c1;//возвращаем текущий цвет рисования
    Figure::c2 = c2;
    Figure::c3 = c3;
   
    switch (key)
    {

    case Cap1://кольцо

        Figure::count++;//увеличить количество фигур данного типа
        Figure::p[Figure::count] = new Ring();
        Figure::p[Figure::count]->display(false);//нарисовать фигуру (сгенирировать местоположение автоматически)
        Figure::flag = false;
        Figure::i = Figure::count;//сделать активной последнюю созданную фигуру
        
        Figure::col1=0;
        Figure::col2=1;
        Figure::col3=1;//голубой
        
        Figure::p[Figure::i]->square();

        if (Figure::count > 0)//если фигур больше одной
        {
            Figure::col1 = 1; 
            Figure::col2 = 1; 
            Figure::col3 = 1;

            for (int i = 0; i < Figure::count+1; i++)//сделать выделение белым у неактивных фигур
            {
                if (i != Figure::i)
                {
                    Figure::p[i]->square();
                }
            }
        }
        
        break;


    case Cap2://звезда
        Figure::count++;//увеличить количество фигур данного типа
        Figure::p[Figure::count] = new Star();
        Figure::p[Figure::count]->display(false);//нарисовать фигуру (сгенирировать местоположение автоматически)
        Figure::flag = false;
        Figure::i = Figure::count;

        Figure::col1 = 0;
        Figure::col2 = 1;
        Figure::col3 = 1;

        Figure::p[Figure::i]->square();

        if (Figure::count > 0)//если фигур больше одной
        {
            Figure::col1 = 1;
            Figure::col2 = 1;
            Figure::col3 = 1;

            for (int i = 0; i < Figure::count + 1; i++)
            {
                if (i != Figure::i)
                {

                    Figure::p[i]->square();

                }
            }
        }

        break;

    case Cap3://треугольник
        Figure::count++;//увеличить количество фигур данного типа
        Figure::p[Figure::count] = new Triangle();
        Figure::p[Figure::count]->display(false);//нарисовать фигуру (сгенирировать местоположение автоматически)
        Figure::flag = false;
        Figure::i = Figure::count;

        Figure::col1 = 0;
        Figure::col2 = 1;
        Figure::col3 = 1;

        Figure::p[Figure::i]->square();

        if (Figure::count > 0)//если фигур больше одной
        {
            Figure::col1 = 1;
            Figure::col2 = 1;
            Figure::col3 = 1;

            for (int i = 0; i < Figure::count + 1; i++)
            {
                if (i != Figure::i)
                {

                    Figure::p[i]->square();

                }
            }
        }

        break;

    case Cap4://квадрат 
        Figure::count++;//увеличить количество фигур данного типа
        Figure::p[Figure::count] = new Rect();
        Figure::p[Figure::count]->display(false);//нарисовать фигуру (сгенирировать местоположение автоматически)
        Figure::flag = false;
        Figure::i = Figure::count;

        Figure::col1 = 0;
        Figure::col2 = 1;
        Figure::col3 = 1;

        Figure::p[Figure::i]->square();

        if (Figure::count > 0)//если фигур больше одной
        {
            Figure::col1 = 1;
            Figure::col2 = 1;
            Figure::col3 = 1;

            for (int i = 0; i < Figure::count + 1; i++)
            {
                if (i != Figure::i)
                {
                    Figure::p[i]->square();
                }
            }
        }

        break;

     case Agg://создание агрегата
         if (Figure::count > -1)//если количество фигур меньше 1й, агрегат создать нельзя 
         {
             if (Figure::aggregate == 0)//пока создание агрегата не завершено (не нажата кнопка end), нельзя создать новый агрегат
             {
                 Figure::count++;//увеличить количество фигур
                 Figure::p[Figure::count] = new Aggregate();
                 Figure::flag = false;
                 
                 Figure::p[Figure::count]->add(Figure::p[Figure::i]);//добавить в агрегат активную фигуру
                 Figure::i = Figure::count;//сделать активным созданный агрегат
                 Figure::aggregate = Figure::i;
                 Figure::p[Figure::i]->display(true);
                 Figure::p[Figure::i]->square();

                 if (Figure::count > 0)//если фигур больше одной
                 {
                     Figure::col1 = 1;//перерисовать выделение у всех фигур, кроме активной, белым
                     Figure::col2 = 1;
                     Figure::col3 = 1;
                     for (int i = 0; i < Figure::count + 1; i++)
                     {
                         if (i != Figure::i)
                         {
                             Figure::p[i]->square();
                         }
                     }
                 }
             }
         }

        break;

    case Cap5: //цвет рисования: красный

        Figure::c1 = 1;
        Figure::c2 = 0;
        Figure::c3 = 0;
        Figure::flag = false;
        break;

    case Cap6: //зеленый
        Figure::c1 = 0;
        Figure::c2 = 1;
        Figure::c3 = 0;
        Figure::flag = false;
        break;

    case Cap7://синий
        Figure::c1 = 0;
        Figure::c2 = 0;
        Figure::c3 = 1;
        Figure::flag = false;
        break;

    case Cap8://изменить цвет на красный

        if (Figure::count > -1)
        {
            Figure::c1 = 1;
            Figure::c2 = 0;
            Figure::c3 = 0;
            Figure::flag = false;
            if (typeid(*(Figure::p[Figure::i])) == typeid(Aggregate))
            {
                Figure::p[Figure::i]->setc1(Figure::c1);
                Figure::p[Figure::i]->setc2(Figure::c2);
                Figure::p[Figure::i]->setc3(Figure::c3);
            }

            Figure::p[Figure::i]->display(true);

        }
        break;

    case Cap9://изменить цвет на зеленый

        if (Figure::count > -1)
        {
            Figure::c1 = 0;
            Figure::c2 = 1;
            Figure::c3 = 0;

            Figure::flag = false;
            if (typeid(*(Figure::p[Figure::i])) == typeid(Aggregate))
            {
                Figure::p[Figure::i]->setc1(Figure::c1);
                Figure::p[Figure::i]->setc2(Figure::c2);
                Figure::p[Figure::i]->setc3(Figure::c3);
            }
            Figure::p[Figure::i]->display(true);
        }
        break;

    case Cap10://изменить цвет на синий

        if (Figure::count > -1)
        {
            Figure::flag = false;
            Figure::c1 = 0;
            Figure::c2 = 0;
            Figure::c3 = 1;
            if (typeid(*(Figure::p[Figure::i])) == typeid(Aggregate))
            {
                Figure::p[Figure::i]->setc1(Figure::c1);
                Figure::p[Figure::i]->setc2(Figure::c2);
                Figure::p[Figure::i]->setc3(Figure::c3);
            }
            Figure::p[Figure::i]->display(true);
        }
        break;

    case Hide:// показать/скрыть 
        
        if (Figure::count > -1)
        {
            Figure::flag = false;
            int c1, c2, c3;//для сохранения текущего выбранного цвета рисования
            c1 = Figure::c1;
            c2 = Figure::c2;
            c3 = Figure::c3;

            if (typeid(Figure::p[Figure::i]) != typeid(Aggregate))//если фигура не агрегат
            {
                if (Figure::p[Figure::i]->getwhite() == 1)//если текущий цвет фигуры белый
                {
                    Figure::c1 = Figure::p[Figure::i]->getc1();//вернуть фигуре ее прошлый цвет
                    Figure::c2 = Figure::p[Figure::i]->getc2();
                    Figure::c3 = Figure::p[Figure::i]->getc3();
                    Figure::p[Figure::i]->setwhite(0);
                    Figure::col1 = 0;
                    Figure::col2 = 1;
                    Figure::col3 = 1;//поменять цвет выделения на голубой

                }

                else// если не белый
                {
                    Figure::c1 = 1;//поменять на белый
                    Figure::c2 = 1;
                    Figure::c3 = 1;
                    Figure::p[Figure::i]->setwhite(1);
                    Figure::col1 = 1;
                    Figure::col2 = 1;
                    Figure::col3 = 1;//поменять цвет выделения на белый

                }

                Figure::p[Figure::i]->display(true);//перерисовать фигуру на том же месте
                Figure::p[Figure::i]->square();//перерисовать выделение 
            }
            else // если агрегат
            {
                if (Figure::p[Figure::i]->getwhite() == 1)//если текущий цвет фигуры белый
                {

                    Figure::p[Figure::i]->setwhite(0);
                    Figure::col1 = 0;
                    Figure::col2 = 1;
                    Figure::col3 = 1;//поменять цвет выделения на голубой

                }

                else// если не белый
                {

                    Figure::p[Figure::i]->setwhite(1);
                    Figure::col1 = 1;
                    Figure::col2 = 1;
                    Figure::col3 = 1;//поменять цвет выделения на белый

                }
                Figure::p[Figure::i]->display(true);
                Figure::p[Figure::i]->square();

            }
        }

        break;
    
    case Move:
        Figure::flag = true;
      
        break;

    case Clear://очистить экран
        Figure::flag = false;
        c1 = Figure::c1;//сохраняем текущий цвет рисования 
        c2 = Figure::c2;
        c3 = Figure::c3;

        Figure::c1 = 1;
        Figure::c2 = 1;
        Figure::c3 = 1;

        Figure::col1 = 1;
        Figure::col2 = 1;
        Figure::col3 = 1;//поменять цвет выделения на белый
        //перерисовываем все фигуры белым цветом 
        if (Figure::count > -1)
        {
            for (int i = 0; i < Figure::count + 1; i++)
            {
                Figure::p[i]->setc1(1);
                Figure::p[i]->setc2(1);
                Figure::p[i]->setc3(1);
                Figure::p[i]->display(true);
                Figure::p[i]->square();//перерисовать выделение у всех фигур на белый

            }
        }
        for (int i = 0; i < Figure::count + 1; i++)
        {
            Figure::p[i]->ClearAgg();//очистка агрегата
        }
        glClearColor(1, 1, 1, 1);//установить белый цвет фона
        glClear(GL_COLOR_BUFFER_BIT);
        //удаляем указатели
        for (int i = 0; i < Figure::count+1; i++)
        {
            Figure::p[i] = NULL;
        }
       
        Figure::c1 = c1;//возвращаем текущий выбранный цвет рисования
        Figure::c2 = c2;
        Figure::c3 = c3;

        glFlush();
        Figure::count= -1;//сбрасываем количество объектов
        Figure::i = 0;//сбрасываем номер активного объекта
      
        break;

    case Path://записать траекторию
      
        if (Figure::StartRec == false)
        {
            Figure::StartRec = true;
            for (int i = 0; i < Figure::indexX; i++)
                Figure::x_[i] = NULL;
            for (int i = 0; i < Figure::indexY; i++)
                Figure::y_[i] = NULL;
            for (int i = 0; i < Figure::indexOrderXY; i++)
                Figure::orderXY[i] = NULL;
            Figure::indexX=0;//навигация на массиву X_
            Figure::indexY=0;//навигация на массиву Y_
            Figure::indexOrderXY=0;//навигация по массиву orderXY
        }
        else 
           Figure::StartRec = false;
        break;

    case PathMove://движение по траектории
       
        Figure::crossing = false;
       
        for (int i = 0; i < sizeof(Figure::orderXY) / sizeof(int); i++)
        {
            //перерисовать фигуру белым на прошлой позиции
            Figure::p[Figure::i]->setwhite(1);
            Figure::c1 = 1;
            Figure::c2 = 1;
            Figure::c3 = 1;
            Figure::col1 = 1;
            Figure::col2 = 1;
            Figure::col3 = 1;
            Figure::p[Figure::i]->square();
            Figure::p[Figure::i]->display(true);
            //
            Figure::indexX = 0;
            Figure::indexY = 0;

            if (typeid(*(Figure::p[Figure::i])) != typeid(Aggregate))//если фигура не агрегат
            {
                for (int i = 0; i < Figure::count + 1; i++)
                {
                    if (Figure::p[Figure::i]->getcrossy1() == Figure::p[i]->getcrossy2() &&
                        Figure::p[Figure::i]->getcrossx1() >= Figure::p[i]->getcrossx1() &&
                        Figure::p[Figure::i]->getcrossx1() <= Figure::p[i]->getcrossx2() ||
                        Figure::p[Figure::i]->getcrossy1() == Figure::p[i]->getcrossy2() &&
                        Figure::p[Figure::i]->getcrossx2() >= Figure::p[i]->getcrossx1() &&
                        Figure::p[Figure::i]->getcrossx2() <= Figure::p[i]->getcrossx2() ||
                        Figure::p[Figure::i]->getcrossy2() == Figure::p[i]->getcrossy1() &&
                        Figure::p[Figure::i]->getcrossx1() >= Figure::p[i]->getcrossx1() &&
                        Figure::p[Figure::i]->getcrossx1() <= Figure::p[i]->getcrossx2() ||
                        Figure::p[Figure::i]->getcrossy2() == Figure::p[i]->getcrossy1() &&
                        Figure::p[Figure::i]->getcrossx2() >= Figure::p[i]->getcrossx1() &&
                        Figure::p[Figure::i]->getcrossx2() <= Figure::p[i]->getcrossx2() ||
                        Figure::p[Figure::i]->getcrossx1() == Figure::p[i]->getcrossx2() &&
                        Figure::p[Figure::i]->getcrossy1() >= Figure::p[i]->getcrossy1() &&
                        Figure::p[Figure::i]->getcrossy1() <= Figure::p[i]->getcrossy2() ||
                        Figure::p[Figure::i]->getcrossx1() == Figure::p[i]->getcrossx2() &&
                        Figure::p[Figure::i]->getcrossy2() >= Figure::p[i]->getcrossy1() &&
                        Figure::p[Figure::i]->getcrossy2() <= Figure::p[i]->getcrossy2() ||
                        Figure::p[Figure::i]->getcrossx2() == Figure::p[i]->getcrossx1() &&
                        Figure::p[Figure::i]->getcrossy1() >= Figure::p[i]->getcrossy1() &&
                        Figure::p[Figure::i]->getcrossy1() <= Figure::p[i]->getcrossy2() ||
                        Figure::p[Figure::i]->getcrossx2() == Figure::p[i]->getcrossx1() &&
                        Figure::p[Figure::i]->getcrossy2() >= Figure::p[i]->getcrossy1() &&
                        Figure::p[Figure::i]->getcrossy2() <= Figure::p[i]->getcrossy2())

                    {
                        Figure::crossing = true;
                        
                    }

                    if (typeid(*(Figure::p[i])) == typeid(Aggregate))//фигуры не могут проходить сквозь агегаты при движении по траектории
                    {
                        for (int j = 0; j < Figure::p[i]->getn() + 1; j++)
                        {
                            if (Figure::p[Figure::i]->getcrossy1() == Figure::p[i]->getcrossy2(j) &&
                                Figure::p[Figure::i]->getcrossx1() >= Figure::p[i]->getcrossx1(j) &&
                                Figure::p[Figure::i]->getcrossx1() <= Figure::p[i]->getcrossx2(j) ||
                                Figure::p[Figure::i]->getcrossy1() == Figure::p[i]->getcrossy2(j) &&
                                Figure::p[Figure::i]->getcrossx2() >= Figure::p[i]->getcrossx1(j) &&
                                Figure::p[Figure::i]->getcrossx2() <= Figure::p[i]->getcrossx2(j) ||
                                Figure::p[Figure::i]->getcrossy2() == Figure::p[i]->getcrossy1(j) &&
                                Figure::p[Figure::i]->getcrossx1() >= Figure::p[i]->getcrossx1(j) &&
                                Figure::p[Figure::i]->getcrossx1() <= Figure::p[i]->getcrossx2(j) ||
                                Figure::p[Figure::i]->getcrossy2() == Figure::p[i]->getcrossy1(j) &&
                                Figure::p[Figure::i]->getcrossx2() >= Figure::p[i]->getcrossx1(j) &&
                                Figure::p[Figure::i]->getcrossx2() <= Figure::p[i]->getcrossx2(j) ||
                                Figure::p[Figure::i]->getcrossx1() == Figure::p[i]->getcrossx2(j) &&
                                Figure::p[Figure::i]->getcrossy1() >= Figure::p[i]->getcrossy1(j) &&
                                Figure::p[Figure::i]->getcrossy1() <= Figure::p[i]->getcrossy2(j) ||
                                Figure::p[Figure::i]->getcrossx1() == Figure::p[i]->getcrossx2(j) &&
                                Figure::p[Figure::i]->getcrossy2() >= Figure::p[i]->getcrossy1(j) &&
                                Figure::p[Figure::i]->getcrossy2() <= Figure::p[i]->getcrossy2(j) ||
                                Figure::p[Figure::i]->getcrossx2() == Figure::p[i]->getcrossx1(j) &&
                                Figure::p[Figure::i]->getcrossy1() >= Figure::p[i]->getcrossy1(j) &&
                                Figure::p[Figure::i]->getcrossy1() <= Figure::p[i]->getcrossy2(j) ||
                                Figure::p[Figure::i]->getcrossx2() == Figure::p[i]->getcrossx1(j) &&
                                Figure::p[Figure::i]->getcrossy2() >= Figure::p[i]->getcrossy1(j) &&
                                Figure::p[Figure::i]->getcrossy2() <= Figure::p[i]->getcrossy2(j))
                            {
                                Figure::crossing = true;
                            }
                        }
                    }

                }

                if (Figure::crossing == false)//если нет столкновения
                {
                   
                   if (Figure::orderXY[i] == 1)
                   {
                        if (Figure::p[Figure::i]->getx() > 20 && Figure::p[Figure::i]->getx() <180)//фигура не может выходить за границу окна
                        {
                            Figure::p[Figure::i]->setx(Figure::x_[Figure::indexX]);
                            Figure::indexX++;
                        }
                   }
                    else
                    {
                        if (Figure::p[Figure::i]->gety() > 16&& Figure::p[Figure::i]->gety() < 180)//фигура не может выходить за границу окна
                        {

                             Figure::p[Figure::i]->sety(Figure::y_[Figure::indexY]);
                             Figure::indexY++;
                            
                        }

                    }
                }

            }
            else//если агрегат
            {
                if (Figure::orderXY[i] == 1)
                {
                    if (Figure::p[Figure::i]->stopLEFT() == 0 && Figure::p[Figure::i]->stopRIGHT() == 0)
                    {

                        Figure::p[Figure::i]->setx(Figure::x_[Figure::indexX]);
                        Figure::indexX++;
                    }
                }
                else
                {
                    if (Figure::p[Figure::i]->stopDOWN() == 0 && Figure::p[Figure::i]->stopUP() == 0)
                    {
                        Figure::p[Figure::i]->sety(Figure::y_[Figure::indexY]);
                        Figure::indexY++;
                    }
                }


            }

            //перерисовать фигуру на новом месте
            Figure::p[Figure::i]->setwhite(0);
            Figure::c1 = Figure::p[Figure::i]->getc1();
            Figure::c2 = Figure::p[Figure::i]->getc2();
            Figure::c3 = Figure::p[Figure::i]->getc3();
            Figure::p[Figure::i]->display(true);
            Figure::col1 = 0;
            Figure::col2 = 1;
            Figure::col3 = 1;
            Figure::p[Figure::i]->square();
            
        }
       
        break;

        case File: //записать конфигурацию в файл
        
           file.open(Figure::path);

           for (int i = 0; i < Figure::count + 1; i++)
           {
               if (typeid(*(Figure::p[i])) == typeid(Aggregate))
               {
                   file << "-1" <<" ";//обозначает начало агрегата
                   int k = 0;
                   for (int j = 0; j < Figure::p[i]->getn() + 1; j++)//перебираем все фигуры в агрегате
                   {
                       if(typeid(*(Figure::p[i]->getA(j))) == typeid(Star))
                       {
                           file << "1";
                       }
                       else if (typeid(*(Figure::p[i]->getA(j))) == typeid(Rect))
                       {
                           file << "2";
                       }
                       else if (typeid(*(Figure::p[i]->getA(j))) == typeid(Ring))
                       {
                           file << "3";
                       }
                       else if (typeid(*(Figure::p[i]->getA(j))) == typeid(Triangle))
                       {
                           file << "4";
                       }

                       file << " ";
                       file << Figure::p[i]->getA(j)->getx() << " ";
                       file << Figure::p[i]->getA(j)->gety() << " ";
                       if (Figure::p[i]->getc1() == 0 && Figure::p[i]->getc2() == 0 && Figure::p[i]->getc3() == 0)
                       {
                          //если цвет агрегата не был ни разу изменен, записать собственный цвет каждой фигуры                          file << Figure::p[i]->getAggcolor(k);
                          file << Figure::p[i]->getAggcolor(k);
                          file << " ";
                          k++;
                          file << Figure::p[i]->getAggcolor(k);
                          file << " ";
                          k++;
                          file << Figure::p[i]->getAggcolor(k);
                          file << " ";
                          k++; 
                       }
                       else
                       {
                           file << Figure::p[i]->getc1() << " " << Figure::p[i]->getc2() << " " << Figure::p[i]->getc3() << " ";
                           //в этом случае для всех фигур будет записан одинаковый цвет
                       }
                       
                   }
                   file << "-2" << " ";//обозначает конец агрегата
               }
               else
               { 
                   if(typeid(*(Figure::p[i]))==typeid(Star))
                   {
                       file << "1" ;
                   }
                   else if (typeid(*(Figure::p[i])) == typeid(Rect))
                   {
                       file << "2" ;
                   }
                   else if (typeid(*(Figure::p[i])) == typeid(Ring))
                   {
                       file << "3" ;
                   }
                   else if (typeid(*(Figure::p[i])) == typeid(Triangle))
                   {
                       file << "4";
                   }
                   file << " ";
                   file << Figure::p[i]->getx() << " " << Figure::p[i]->gety() << " " << Figure::p[i]->getc1() << " " << Figure::p[i]->getc2() << " " << Figure::p[i]->getc3();
                  
                   file << " ";
               }
           }

           file.close();

            break;

        case ReadFile://восстановить конфигурацию из текстового файла
            
           file1.open(Figure::path);

            if (Figure::count < 0 )// чтение из файла возможно если нет ни одной фигуры
            {
                int agg = 0;
                Figure::count++;
                int c; 
                float a;
                while (file1)
                {
                    file1 >> c;
                   
                    if (c == 1)
                    {
                        Figure::p[Figure::count] = new Star;
                      
                        file1 >> a;

                        Figure::p[Figure::count]->setx1(a);

                        file1 >> a;
                        Figure::p[Figure::count]->sety1(a);

                        file1 >> a;
                     
                        Figure::p[Figure::count]->setc1(a);

                        file1 >> a;
                     
                        Figure::p[Figure::count]->setc2(a);

                        file1 >> a;
                       
                        Figure::p[Figure::count]->setc3(a);

                        Figure::count++;
                      
                    }
                    else if (c == 2)
                    {
                        Figure::p[Figure::count] = new Rect;
                        
                        file1 >> a;

                        Figure::p[Figure::count]->setx1(a);

                        file1 >> a;
                        Figure::p[Figure::count]->sety1(a);

                        file1 >> a;
                    
                        Figure::p[Figure::count]->setc1(a);

                        file1 >> a;
                      
                        Figure::p[Figure::count]->setc2(a);

                        file1 >> a;
                    
                        Figure::p[Figure::count]->setc3(a);

                        Figure::count++;
                
                    }
                    else if (c == 3)
                    {
                        Figure::p[Figure::count] = new Ring;
                       
                        file1 >> a;

                        Figure::p[Figure::count]->setx1(a);

                        file1 >> a;
                        Figure::p[Figure::count]->sety1(a);

                        file1 >> a;
                        
                        Figure::p[Figure::count]->setc1(a);

                        file1 >> a;
                        
                        Figure::p[Figure::count]->setc2(a);

                        file1 >> a;
                        
                        Figure::p[Figure::count]->setc3(a);

                        Figure::count++;
                      
                    }
                    else if (c ==4)
                    {
                        Figure::p[Figure::count] = new Triangle;
                        
                        file1 >> a;

                        Figure::p[Figure::count]->setx1(a);

                        file1 >> a;
                        Figure::p[Figure::count]->sety1(a);

                        file1 >> a;
                        
                        Figure::p[Figure::count]->setc1(a);

                        file1 >> a;
                        
                        Figure::p[Figure::count]->setc2(a);

                        file1 >> a;
                      
                        Figure::p[Figure::count]->setc3(a);

                        Figure::count++;
                    }

                    else if (c == -1)//агрегат
                    {
                        Figure::p[Figure::count] = new Aggregate;
                        file1 >> c;
                        int j = 0;
                        int k = 0;

                        while (c != -2)
                        {
                            if (c == 1)
                            {
                                Figure::p[Figure::count]->setA(j, 1);
                            }
                            else if (c == 2)
                            {
                                Figure::p[Figure::count]->setA(j, 2);
                            }
                            else if (c == 3)
                            {
                                Figure::p[Figure::count]->setA(j, 3);
                            }
                            else if (c == 4)
                            {
                                Figure::p[Figure::count]->setA(j, 4);
                            }
                            
                            file1 >> c;
                            Figure::p[Figure::count]->getA(j)->setx1(c);

                            file1 >> c;
                            Figure::p[Figure::count]->getA(j)->sety1(c);
                            
                            file1 >> c;
                            Figure::p[Figure::count]->setc1(c); 
                            Figure::p[Figure::count]->setAggcolor(k,c);
                            k++;
                            
                            file1 >> c;
                            Figure::p[Figure::count]->setc2(c); 
                            Figure::p[Figure::count]->setAggcolor(k, c);
                            k++;

                            file1 >> c;
                            Figure::p[Figure::count]->setc3(c);
                            Figure::p[Figure::count]->setAggcolor(k, c);
                            
                            Figure::p[Figure::count]->setn(k);
                            k++;

                            Figure::p[Figure::count]->setn(j);
                            j++;
                            file1 >> c;

                        }
                        agg = 1;
                        Figure::count++;
                       
                    }
                }

                    Figure::p[Figure::count] = NULL;
                    Figure::count--;
                    if (agg == 0) {Figure::count--;}
                    Figure::i = Figure::count;

                    int c1, c2, c3;
                    c1 = Figure::c1;
                    c2 = Figure::c2;
                    c3 = Figure::c3;

                    for (int i = 0; i < Figure::count+1; i++)
                    {
                        Figure::c1 = Figure::p[i]->getc1();
                        Figure::c2 = Figure::p[i]->getc2();
                        Figure::c3 = Figure::p[i]->getc3();
                        Figure::p[i]->display(true);
                    }

                    Figure::c1 = c1;
                    Figure::c2 = c2;
                    Figure::c2 = c3;

                    Figure::col1 = 0;
                    Figure::col2 = 1;
                    Figure::col3 = 1;//цвет выделения активной фигуры - голубой
                    Figure::p[Figure::i]->square();
                    file1.close();
            }
            
            break;
    }
}

void display(void)
{
    glClear(GL_COLOR_BUFFER_BIT);
   
    int menu1 = glutCreateMenu(Menu);
    glutAddMenuEntry("Круг", Cap1);
    glutAddMenuEntry("Звезда", Cap2);
    glutAddMenuEntry("Треугольник", Cap3);
    glutAddMenuEntry("Квадрат", Cap4);

    int menu2 = glutCreateMenu(Menu);
    glutAddMenuEntry("Красный", Cap5);
    glutAddMenuEntry("Зеленый", Cap6);
    glutAddMenuEntry("Синий", Cap7);

    int menu3 = glutCreateMenu(Menu);
    glutAddMenuEntry("Красный", Cap8);
    glutAddMenuEntry("Зеленый", Cap9);
    glutAddMenuEntry("Синий", Cap10);

    int menu = glutCreateMenu(Menu);
    glutAddSubMenu("Создать фигуру", menu1);
    glutAddMenuEntry("Создать агрегат", Agg);
    glutAddSubMenu("Выбрать цвет рисования", menu2);
    glutAddSubMenu("Изменить цвет на:", menu3);
    glutAddMenuEntry("Показать/скрыть", Hide);
    glutAddMenuEntry("Движение", Move);
    glutAddMenuEntry("Записать в файл", File);
    glutAddMenuEntry("Восстановить конфигурацию из файла", ReadFile);
    glutAddMenuEntry("Записать траекторию", Path);
    glutAddMenuEntry("Движение по траектории", PathMove);
    glutAddMenuEntry("Очистить окно", Clear);

    glutAttachMenu(GLUT_RIGHT_BUTTON);

}

void main(int argc, char ** argv)
{
    setlocale(LC_ALL, "Russian");
    srand(time(0));
  
    glutInit(&argc, argv);
    glutCreateWindow("2D_graphics");
    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE);
    glutInitWindowPosition(100, 100);
    glutInitWindowSize(900, 700);
    glClearColor(1, 1, 1, 1);
    glClear(GL_COLOR_BUFFER_BIT);
    
    gluOrtho2D(0, 200, 200, 0);
    glViewport(0, 0, 900, 700);

    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutSpecialFunc(keyboard);

    cout << "Подсказка" << endl;
    cout << "Переместить выделение на следующую фигуру - F3 (F3+Fn) " << endl;
    cout << "Меню можно открыть правым щелчком мыши" << endl;
    cout << "Создание агрегата - кнопка создать агрегат в меню, при этом в агрегат автоматически добавляется активный объект, а другие фигуры можно добавить, сделав их активными и нажав клавишу F4. Создание агрегата обязательно закончить клавишей INSERT" << endl;
    cout << "Чтобы начать двигать любую фигуру, нужно сделать ее активной и выбрать в меню пункт Движение" << endl;
    cout << "Запись траектории - выбрать в меню пункт Записать траекторию, а затем - Движение, и начать перемещать объект, все перемещения будут записаны, остановить запись - нажать снова на пункт Записать траекторию, и запись будет остановлена"<< endl;
    cout << "Текущую конфигурацию программы можно записать в файл. Для этого нужно нажать на соответствующий пункт в меню. Чтобы восстановить конфигурацию из файла, нужно чтобы на экране не было ни одной фигуры" << endl;
    cout << "Чтобы удалить все созданные фигуры, нажмите кнопку Очистить экран." << endl;
    
    if(argc >0)
        Figure::path = argv[1];

    glutMainLoop();
}


