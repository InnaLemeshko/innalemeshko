#pragma once

#include <typeinfo>
#include "figure.h"
#include "aggregate.h"
#include "Star.h"
#include "Rect.h"
#include "Triangle.h"


void Aggregate::add(Figure*p)
{
    if (typeid(*p) != typeid(Aggregate))
    {
        n++;

        a[n] = p->create();
        a[n]->setx1(p->getx());
        a[n]->sety1(p->gety());

        //�������� ���� ����� ������ � ������ 
        Aggcolor[n1] = p->getc1();
        n1++;

        Aggcolor[n1] = p->getc2();
        n1++;

        Aggcolor[n1] = p->getc3();
        n1++;
    }
    else 
    {
        for (int i = 0; i < p->getn()+1; i++)
        {
            n++;
            Figure* p1;
            p1 = p->getA(i);

            if (typeid(*p1) == typeid(Ring))
            {
                a[n] = new Ring();
            }
            else if (typeid(*p1) == typeid(Star))
            {
                a[n] = new Star();
            }
            else if (typeid(*p1) == typeid(Rect))
            {
                a[n] = new Rect();
            }
            else if (typeid(*p1) == typeid(Triangle))
            {
                a[n] = new Triangle();
            }

            a[n]->setx1(p1->getx());
            a[n]->sety1(p1->gety());
            Aggcolor[n1] = p1->getc1();
            n1++;
            Aggcolor[n1] = p1->getc2();
            n1++;
            Aggcolor[n1] = p1->getc3();
            n1++;
        }

    }
   
}
void Aggregate::setA(int j, int h)
{

    if (h == 1)
    {
        a[j] = new Star;
    }
    else if (h == 2)
    {
        a[j] = new Rect;
    }
    else if (h == 3)
    {
        a[j] = new Ring;
    }
    else if (h == 4)
    {
        a[j] = new Triangle;
    }
}


int Aggregate::getAggcolor(int i)
{

    return Aggcolor[i];
}

void Aggregate::setAggcolor(int i, int c)
{

    Aggcolor[i] = c;
}



void Aggregate::setc1(int c1)
{
    this->c1 = c1;
}

void Aggregate::setc2(int c2)
{
    this->c2 = c2;
}

void Aggregate::setc3(int c3)
{
    this->c3 = c3;
}


void Aggregate::display(bool flag)
{
    if (c1 == 0 && c2 == 0 && c3 == 0)//���� ���� �������� �� ��� �� ���� �������, ���������� ������ ������ ����������� ������
    {
        n1 = 0;
        for (int i = 0; i < n + 1; i++)
        {
            if (white == 0)
            {
                Figure::c1 = Aggcolor[n1];
                n1++;
                Figure::c2 = Aggcolor[n1];
                n1++;
                Figure::c3 = Aggcolor[n1];
                n1++;
            }
            else
            {
                Figure::c1 = 1;
                Figure::c2 = 1;
                Figure::c3 = 1;
            }
            a[i]->display(true);
        }

    }

    else//����� ���������� ��� ������ �������� ����� ������
    {
        for (int i = 0; i < n + 1; i++)
        {
            if (white == 0)
            {
                Figure::c1 = c1;
                Figure::c2 = c2;
                Figure::c3 = c3;
            }
            else
            {
                Figure::c1 = 1;
                Figure::c2 = 1;
                Figure::c3 = 1;
            }
            a[i]->display(true);
        } 
    }
}

void Aggregate::square()
{
    for (int i = 0; i < n + 1; i++)
       a[i]->square();
}


float Aggregate::getxi(int i)
{
    return a[i]->getx();
}

float Aggregate::getyi(int i)
{
    return a[i]->gety();
}


void  Aggregate::setn(int i)
{
    n = i;
}

void Aggregate::setn1(int i)
{
    n1 = i;
}

void Aggregate::setx(float step)
{
        if (step == -1)//�������� �����
        { 
            Figure::crossing = false;

            for (int j = 0; j < n + 1; j++)
            {
                for (int i = 0; i < Figure::count + 1; i++)
                {
                    if (i != Figure::i)
                    {
                        if (a[j]->getcrossx1() == Figure::p[i]->getcrossx2() &&
                            a[j]->getcrossy1() >= Figure::p[i]->getcrossy1() &&
                            a[j]->getcrossy1() <= Figure::p[i]->getcrossy2() ||
                            a[j]->getcrossx1() == Figure::p[i]->getcrossx2() &&
                            a[j]->getcrossy2() >= Figure::p[i]->getcrossy1() &&
                            a[j]->getcrossy2() <= Figure::p[i]->getcrossy2())
                        {
                            Figure::crossing = true;

                        }
                    }
                }
            }
            if (Figure::crossing == false)
            {
                for (int i = 0; i < n + 1; i++)
                {
                    if (a[i]->getx() > 20)
                    {
                        a[i]->setx(step);
                        Aggregate::stopDOWN1 = 0;
                        Aggregate::stopRIGHT1 = 0;
                        Aggregate::stopLEFT1 = 0;
                        Aggregate::stopUP1 = 0;
                    }
                    else
                    {
                        Aggregate::stopLEFT1 = 1;
                        Aggregate::stopRIGHT1 = 0;
                        Aggregate::stopUP1 = 0;
                        Aggregate::stopDOWN1 = 0;
                        break;

                    }
                }
            }
        }
        else
        {

            Figure::crossing = false;

            for (int j = 0; j < n + 1; j++)
            {
                for (int i = 0; i < Figure::count + 1; i++)
                {
                    if (i != Figure::i)
                    {
                        if (a[j]->getcrossx2() == Figure::p[i]->getcrossx1() &&
                            a[j]->getcrossy1() >= Figure::p[i]->getcrossy1() &&
                            a[j]->getcrossy1() <= Figure::p[i]->getcrossy2() ||
                            a[j]->getcrossx2() == Figure::p[i]->getcrossx1() &&
                            a[j]->getcrossy2() >= Figure::p[i]->getcrossy1() &&
                            a[j]->getcrossy2() <= Figure::p[i]->getcrossy2())
                        {
                            Figure::crossing = true;

                        }
                    }
                }

            if (Figure::crossing == false)
            {
                for (int i = 0; i < n + 1; i++)
                {
                    if (a[i]->getx() < 190)
                    {
                        a[i]->setx(step);
                        Aggregate::stopDOWN1 = 0;
                        Aggregate::stopRIGHT1 = 0;
                        Aggregate::stopLEFT1 = 0;
                        Aggregate::stopUP1 = 0;
                    }
                    else
                    {
                        Aggregate::stopRIGHT1 = 1;
                        Aggregate::stopLEFT1 = 0;
                        Aggregate::stopUP1 = 0;
                        Aggregate::stopDOWN1 = 0;
                        break;
                    }
                }
            }
        }
    }
}

int Aggregate::getn()
{
    return n;
}


Figure *Aggregate::getA(int i)
{
    return a[i];
}


void Aggregate::sety(float step)
{
   
        if (step == -1)
        {

            Figure::crossing = false;

            for (int j = 0; j < n + 1; j++)
            {
                for (int i = 0; i < Figure::count + 1; i++)
                {
                    if (i != Figure::i)
                    {
                        if (a[j]->getcrossy1() == Figure::p[i]->getcrossy2() &&
                            a[j]->getcrossx1() >= Figure::p[i]->getcrossx1() &&
                            a[j]->getcrossx1() <= Figure::p[i]->getcrossx2() ||
                            a[j]->getcrossy1() == Figure::p[i]->getcrossy2() &&
                            a[j]->getcrossx2() >= Figure::p[i]->getcrossx1() &&
                            a[j]->getcrossx2() <= Figure::p[i]->getcrossx2())
                        {
                            Figure::crossing = true;

                        }
                    }
                }
            }
            if (Figure::crossing == false)
            {

                for (int i = 0; i < n + 1; i++)
                {
                    if (a[i]->gety() > 26)
                    {
                        a[i]->sety(step);
                        Aggregate::stopDOWN1 = 0;
                        Aggregate::stopRIGHT1 = 0;
                        Aggregate::stopLEFT1 = 0;
                        Aggregate::stopUP1 = 0;
                    }
                    else
                    {
                        Aggregate::stopUP1 = 1;
                        Aggregate::stopRIGHT1 = 0;
                        Aggregate::stopLEFT1 = 0;

                        Aggregate::stopDOWN1 = 0;
                        break;

                    }
                }
            }
        }

        else
        {
            Figure::crossing = false;

            for (int j = 0; j < n + 1; j++)
            {
                for (int i = 0; i < Figure::count + 1; i++)
                {
                    if (i != Figure::i)
                    {
                        if (a[j]->getcrossy2() == Figure::p[i]->getcrossy1() &&
                            a[j]->getcrossx1() >= Figure::p[i]->getcrossx1() &&
                            a[j]->getcrossx1() <= Figure::p[i]->getcrossx2() ||
                            a[j]->getcrossy2() == Figure::p[i]->getcrossy1() &&
                            a[j]->getcrossx2() >= Figure::p[i]->getcrossx1() &&
                            a[j]->getcrossx2() <= Figure::p[i]->getcrossx2())
                        {
                            Figure::crossing = true;

                        }
                    }
                }
            }
            if (Figure::crossing == false)
            {


                for (int i = 0; i < n + 1; i++)
                {
                    if (a[i]->gety() < 175)
                    {
                        a[i]->sety(step);

                        Aggregate::stopDOWN1 = 0;
                        Aggregate::stopRIGHT1 = 0;
                        Aggregate::stopLEFT1 = 0;
                        Aggregate::stopUP1 = 0;

                    }
                    else
                    {
                        Aggregate::stopDOWN1 = 1;
                        Aggregate::stopRIGHT1 = 0;
                        Aggregate::stopLEFT1 = 0;
                        Aggregate::stopUP1 = 0;

                        break;
                    }
                }
            }
        }
    
}

int Aggregate::stopUP()
{
    return Aggregate::stopUP1;
}
int Aggregate::stopDOWN()
{
    return Aggregate::stopDOWN1;
}

int Aggregate::stopLEFT()
{
    return Aggregate::stopLEFT1;
}

int Aggregate::stopRIGHT()
{
    return Aggregate::stopRIGHT1;
}


int Aggregate::getwhite()
{
    return white;
}

int Aggregate::getc1()
{
    return c1;
}

int Aggregate::getc2()
{
    return c2;
}

int Aggregate::getc3()
{
    return c3;
}

void Aggregate::setwhite(int i)
{
    white = i;
}

Aggregate::~Aggregate()
{
    delete[] a;
}

void Aggregate::ClearAgg()
{
    n = -1;
    white = 0;
    for (int i = 0; i < n + 1; i++)
    {
        a[i] = NULL;
    }

}


//��� ����������� ������������ ������ � ���������
float Aggregate::getcrossx1(int i)
{
    return a[i]->getcrossx1();
}
float Aggregate::getcrossx2(int i)
{
    return a[i]->getcrossx2();
}
float Aggregate::getcrossy1(int i)
{
    return a[i]->getcrossy1();
}
float Aggregate::getcrossy2(int i)
{
    return a[i]->getcrossy2();
}