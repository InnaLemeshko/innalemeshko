#pragma once

#include "figure.h"
#include "Star.h"


void Star::display(bool flag)
{
    if (flag == false)
    {
        x = getRandomNumber(30, 160);
        y = getRandomNumber(30, 160);
    }

    drawStar(x, y);

    glFlush();
  

}

void Star::drawStar(float x, float y)
{
    glBegin(GL_LINE_LOOP);

    glColor3f(Figure::c1, Figure::c2, Figure::c3);
    
    if (white == 0)//���� ������� ���� �� ����� ������, ��������� ���� �������
    {
        Star::c1 = Figure::c1;
        Star::c2 = Figure::c2;
        Star::c3 = Figure::c3;
    }

    glVertex2f(x, y);
    glVertex2f(x-18, y-10);
    glVertex2f(x+2, y-10);
    glVertex2f(x-16, y);
    glVertex2f(x-8, y-15);

    glEnd();
}


void Star::square()
{
    glEnable(GL_LINE_STIPPLE);//��������� ������ ���������� �����
    glLineStipple(1, 0x00F0);

    glBegin(GL_LINE_LOOP);
    glColor3f(Figure::col1, Figure::col2, Figure::col3);

    glVertex2f(x-23, y-20);
    glVertex2f(x+7, y-20);
    glVertex2f(x+7, y+5);
    glVertex2f(x-23, y+5);

    crossx1 = x - 23;
    crossx2 = x + 7;
    crossy1 = y - 20;
    crossy2 = y + 5;

    glEnd();
    glDisable(GL_LINE_STIPPLE);
    glFlush();
    
    
}


void Star::setc1(int c1)
{
    this->c1 = c1;
}

void Star::setc2(int c2)
{
    this->c2 = c2;
}

void Star::setc3(int c3)
{
    this->c3 = c3;
}

void Star::setx1(float x)
{
    this->x = x;
}

void Star::sety1(float y)
{
    this->y = y;
}

//��� ����������� ������������ 
float Star::getcrossx1()
{
    return Star::crossx1;
}
float Star::getcrossx2()
{
    return Star::crossx2;
}
float Star::getcrossy1()
{
    return Star::crossy1;
}
float Star::getcrossy2()
{
    return Star::crossy2;
}

int Star::getwhite()
{
    return white; 
}

int Star::getc1()
{
    return  Star::c1;
}
int Star::getc2()
{
    return  Star::c2;
}
int Star::getc3()
{
    return  Star::c3;
}

void Star::setwhite(int i)
{
    white = i;
}

float Star::getx()
{
    return x;
}
float Star::gety()
{
    return y;
}
void Star::setx(float step)
{
    this->x += step;
}

void Star::sety(float step)
{
    this->y += step;
}